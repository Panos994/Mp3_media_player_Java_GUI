# JukeBox

## To clean packages
    mvn clean

## To compile 
    mvn package

## To run 
    java -jar target/Jukebox4-1.0-SNAPSHOT.jar


### Valid strategy  
    play, random, order, loop (not functioning), next, resume, pause, stop
