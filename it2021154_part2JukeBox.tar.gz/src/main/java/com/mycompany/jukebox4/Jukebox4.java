
package com.mycompany.jukebox4;

import com.mycompany.buttons.Frame;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;


public class Jukebox4 {

    public static void main(String[] args) throws FileNotFoundException {
        new Frame();
    }
}
